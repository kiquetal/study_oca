/**
 * 
 */
package com.apress.isf.spring;

/**
 * @author Felipe Gutierrez
 *
 */
public class HelloWorldMessage implements MessageService {
	
	public String getMessage() {
		return "Hello World";
	}
}
