/**
 * 
 */
package com.apress.isf.spring;

/**
 * @author Felipe Gutierrez
 *
 */
public interface MessageService {
	public String getMessage();
}
