/**
 * 
 */
package com.apress.isf.spring.integration;

/**
 * @author Felipe Gutierrez
 *
 */
public class DocumentServiceActivator {

}
