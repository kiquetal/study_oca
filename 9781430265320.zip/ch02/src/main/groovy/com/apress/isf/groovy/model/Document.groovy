/**
 * 
 */
package com.apress.isf.groovy.model

/**
 * @author Felipe Gutierrez
 *
 */
class Document {
	String name
	Type type
	String location
}
