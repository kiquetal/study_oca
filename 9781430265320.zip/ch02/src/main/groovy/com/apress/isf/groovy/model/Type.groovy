/**
 * 
 */
package com.apress.isf.groovy.model

/**
 * @author Felipe Gutierrez
 *
 */
class Type {
	String name
	String desc
	String extension
}
