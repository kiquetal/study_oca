/**
 * 
 */
package com.apress.isf.spring.web;

import org.springframework.stereotype.Controller;

/**
 * @author Felipe Gutierrez
 *
 */
@Controller
public class DocumentController {

}
